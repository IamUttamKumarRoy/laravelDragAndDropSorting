<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Post;

class PostController extends Controller
{

    public function index()
    {
        $posts = Post::orderBy('order','ASC')->get();
        return view('drag_drop_sorting.post',compact('posts'));
    }


    public function update(Request $request)
    {
        $posts = Post::all();
        //print_r($posts);
        foreach ($posts as $post) {
            foreach ($request->order as $order) {
            	echo "<pre>";
            	print_r($order);
            	echo "</pre>";
                if ($order['id'] == $post->id) {
                    $post->update(['order' => $order['position']]);
                }
            }
        }
        return response('Update Successfully.', 200);
        die;
    }

}
