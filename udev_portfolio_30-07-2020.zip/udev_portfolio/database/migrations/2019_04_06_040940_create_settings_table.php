<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateSettingsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->smallInteger('id')->unsigned()->autoIncrement();
            $table->tinyInteger('input_type_id')->unsigned()->nullable();
            $table->string('variable_group',50)->nullable();
            $table->string('variable_name',50);
            $table->string('variable_display_title',50)->nullable();
            $table->text('variable_value')->nullable();        
            $table->tinyInteger('is_singular')->unsigned()->nullable();
            $table->tinyInteger('status')->unsigned()->nullable();
            $table->integer('created_by')->nullable();
            $table->timestamp('created_at')->nullable();
            $table->integer('updated_by')->nullable();
            $table->timestamp('updated_at')->nullable();
            $table->string('terminal',100)->nullable();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('settings');
    }
}
