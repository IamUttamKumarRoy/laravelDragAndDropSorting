<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreatePrivilegeMenusTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('privilege_menus', function (Blueprint $table) {           
            $table->smallInteger('id')->unsigned()->autoIncrement();
            $table->tinyInteger('privilege_menu_category_id')->unsigned()->nullable();
            $table->string('privilege_name',30);
            $table->string('uri',60);
            $table->string('route_name',60);
            $table->string('methods',10)->nullable();
            $table->string('action',60)->nullable();
            $table->string('controller',50);
            $table->smallInteger('ordering')->unsigned()->nullable();
            $table->tinyInteger('status')->unsigned()->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('privilege_menus');
    }
}
