<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;

class PrivilegeMenuCategorysSeederTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('App\PrivilegeMenuCategory');
        for($i = 1 ; $i <= 15 ; $i++) {
	        DB::table('privilege_menu_categories')->insert([
	        	'category_name' => $faker->word(),
	        	'precedence' => $faker->numberBetween(1,100),
	        	'ordering' => $faker->numberBetween(1,100),
	        	'status' => 1,
	        	'created_at' => \Carbon\Carbon::now(),
	        	'Updated_at' => \Carbon\Carbon::now(),
	        ]);
        } 
    }
}
