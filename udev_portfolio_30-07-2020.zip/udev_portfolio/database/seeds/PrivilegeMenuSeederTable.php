<?php

use Illuminate\Database\Seeder;
use Faker\Factory as Faker;
use App\PrivilegeMenuCategory;

class PrivilegeMenuSeederTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $faker = Faker::create('App\PrivilegeMenu');
        for($i = 1 ; $i <= 15 ; $i++) {
	        DB::table('privilege_menus')->insert([
	        	'privilege_menu_category_id' => PrivilegeMenuCategory::all()->random()->id,
	        	'privilege_name' => $faker->word(),
	        	'uri' => $faker->word(),
	        	'methods' => $faker->word(),
	        	'action' => $faker->word(),
	        	'controller' => $faker->word(),
	        	'ordering' => $faker->numberBetween(1,100),
	        	'status' => 1,
	        	'created_at' => \Carbon\Carbon::now(),
	        	'Updated_at' => \Carbon\Carbon::now(),
	        ]);
        } 
    }
}
