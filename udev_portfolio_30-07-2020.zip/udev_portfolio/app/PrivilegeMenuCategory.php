<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PrivilegeMenuCategory extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'category_name',
        'precedence'
    ];

    /**
     * The roles that belong to the user.
     */
    public function privilege_menus()
    {
        return $this->belongsToMany(PrivilegeMenu::class,'user_role_privilege_menu');
    }
}
