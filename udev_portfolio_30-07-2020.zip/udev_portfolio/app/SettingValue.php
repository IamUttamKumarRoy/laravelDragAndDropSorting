<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SettingValue extends Model
{
    public function setting()
    {
        return $this->belongsTo(Setting::class);
    }
}
