<?php
namespace App\CommonClass;
 
class Common{
 
   public function getName() {
        return 'Arjun';
    }
 
    public static function getLastName() {
        return 'PHP';
    }
 
}
?>