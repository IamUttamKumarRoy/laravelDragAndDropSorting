<?php

namespace App\CommonClass;

use Illuminate\Http\Request; 
use App\Setting;

class SettingOption
{
	public function __construct() 
	{ 
	}

	public function showForm( $website_settings = null , $website_setting_values = null ) 
	{	   
	   echo view('settings.site_setting',compact('website_settings','website_setting_values'));
	}

	public function getValues( $website_settings = null) 
	{	   
	  	$website_setting_values = array();

	  	$setting_ids = array();

	  	if( !empty( $website_settings ) )
	  	{
	  		foreach ( $website_settings as $key => $ws_row ) 
	  		{
	  			$setting_ids[$ws_row['id']] =  $ws_row['id'];
	  		}
	  	}

	  	$variable_values = Setting::whereIn('variable_name', $setting_ids)->get();

	  	if( !empty($variable_values) )
	  	{
	  		foreach ($variable_values as $key => $vv_row ) 
	  		{
	  			$website_setting_values[$vv_row->variable_name] = $vv_row->variable_value;
	  		}
	  	}

	  	return $website_setting_values;
	}
  	
  	public function saveFormInput(Request $request) 
	{	   
	   if( !empty($request->all()) )
	   {
	      $variable_group = '';
	   	  // Get setting group if any with name  
	   	  foreach ($request->all() as $field_name => $field_value) 
	   	  {
	   	  	if( $field_name == 'variable_group' ) 
	   	  	{
	   	  		$variable_group = $field_value;
	   	  		break;
	   	  	}
	   	  }

	   	  foreach ($request->all() as $field_name => $field_value) 
	   	  {
	   	  	if( $field_name == "_token" || $field_name == "variable_group")
	   	  		continue;

	   	  	if ($request->hasFile($field_name)) {
			   //print_r($request->all());die;
			    // Get filename with extension            
	            $filenameWithExt = $request->file($field_name)->getClientOriginalName();
	            // Get just filename
	            $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);            
	           // Get just ext
	            $extension = $request->file($field_name)->getClientOriginalExtension();
	            //Filename to store
	            $fileNameToStore = $filename.'_'.time().'.'.$extension;                       
	          // Upload Image
	            $path = $request->file($field_name)->    storeAs('public/setting_images', $fileNameToStore);

	            $setting_option = Setting::firstOrNew(array('variable_name' => $field_name));
				$setting_option->variable_group = $variable_group;
				$setting_option->variable_value = $fileNameToStore;
				$setting_option->save();
			} 
			else 
			{
				$setting_option = Setting::firstOrNew(array('variable_name' => $field_name));
				$setting_option->variable_group = $variable_group;
				$setting_option->variable_value = $field_value;
				$setting_option->save();
			}
	   	  }
	   }	   
	}
	// End saveFormInput

}
?>