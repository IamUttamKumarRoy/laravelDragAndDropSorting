<?php

namespace App\Http\Middleware;

use App\PrivilegeMenu;
use Closure;

class CheckPrivilege
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {      
        $uri = $request->route()->uri;
        $method = $request->route()->methods[0];
        $method_end = !empty($request->route()->methods[1]) ? $request->route()->methods[1] :'';
        $route_name = !empty($request->route()->action['as']) ? $request->route()->action['as'] :'';
        pr($uri);
        pr($method);
        pr($method_end);
        pr($route_name);

        $matchThese = ['uri' => $uri, 'route_name' => $route_name];

        $results = PrivilegeMenu::where($matchThese)->get();

        pr($results);
        dd($request->route());
        return $next($request);

        /*if( auth()->user()->isAdmin == 1 ) {
            return $next($request);
        }
        return redirect('home')->with('error','You have not admin access');*/
    }
}
