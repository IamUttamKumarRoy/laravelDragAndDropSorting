<?php

namespace App\Http\Controllers;

use App\PrivilegeMenuCategory;
use Illuminate\Http\Request;

class PrivilegeMenuCategoryController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $privilege_menu_categories = PrivilegeMenuCategory::all();
        return view('privilege_menu_categories.index', compact('privilege_menu_categories'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('privilege_menu_categories.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $validatedData = $request->validate([
             'category_name' => 'required|max:30',
             'precedence' => 'required' 
        ]);
        $validatedData['status'] = 1;
        
        $privilege_menu_categories = PrivilegeMenuCategory::create($validatedData);

        return redirect('/privilege_menu_categories')->with('success', 'Privilege Menu Category is successfully saved');
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\PrivilegeMenuCategory  $privilegeMenuCategory
     * @return \Illuminate\Http\Response
     */
    public function show(PrivilegeMenuCategory $privilegeMenuCategory)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\PrivilegeMenuCategory  $privilegeMenuCategory
     * @return \Illuminate\Http\Response
     */
    public function edit(PrivilegeMenuCategory $privilegeMenuCategory)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\PrivilegeMenuCategory  $privilegeMenuCategory
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, PrivilegeMenuCategory $privilegeMenuCategory)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\PrivilegeMenuCategory  $privilegeMenuCategory
     * @return \Illuminate\Http\Response
     */
    public function destroy(PrivilegeMenuCategory $privilegeMenuCategory)
    {
        //
    }
}
