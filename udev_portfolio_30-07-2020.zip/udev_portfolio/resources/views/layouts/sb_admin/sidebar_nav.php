<ul class="nav" id="side-menu">                        
    <li>
        <a href="#"><i class="fa fa-dashboard fa-fw"></i> Dashboard</a>
    </li>
</ul>