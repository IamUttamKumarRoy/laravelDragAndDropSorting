@extends('layouts.sb_admin')

@section('content')
            <h1>Showing Book {{ $section_type->book_name }}</h1>

    <div class="jumbotron text-center">
        <p>
            <strong>Book Title:</strong> {{ $section_type->section_type }}<br> 
        </p>
    </div>
@endsection