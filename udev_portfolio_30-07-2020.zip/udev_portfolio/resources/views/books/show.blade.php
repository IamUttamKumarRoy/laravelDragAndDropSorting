@extends('layouts.layout')

@section('content')
            <h1>Showing Book {{ $book->book_name }}</h1>

    <div class="jumbotron text-center">
        <p>
            <strong>Book Title:</strong> {{ $book->book_name }}<br>
            <strong>Isbn No:</strong> {{ $book->isbn_no }}
            <strong>Book Price:</strong> {{ $book->book_price }}
        </p>
    </div>
@endsection