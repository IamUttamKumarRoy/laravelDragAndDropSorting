@extends('layouts.sb_admin')

@section('content')
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Section Type
            </div>
            <div class="panel-body">
                @if ($errors->any())
                <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div><br />
                @endif
                <form method="post" action="{{ route('role_privileges.store') }}">
                    @csrf  

                    @if(!empty($privilege_menu_arr))
                        @foreach($privilege_menu_arr as $cat_id=>$privilege_menu) 
                            <div class="row"> 
                                <div class="col-md-12">                                
                                    <div class="form-check-inline">
                                        <label class="form-check-label" for="Category{{$cat_id}}">
                                            <input type="checkbox" class="form-check-input parentPr" id="privilegeParent{{$cat_id}}" name="privilegeParent[]" value="{{$cat_id}}"> {{ (!empty($priv_category_list[$cat_id])) ? ucfirst($priv_category_list[$cat_id]):'' }}
                                        </label>
                                    </div>                                
                                    <div class="children">
                                    @if(!empty($privilege_menu))
                                        @foreach($privilege_menu as $cat_id=>$privilege) 
                                        <div class="form-check-inline">
                                          <label class="form-check-label" for="check{{$privilege['id']}}">
                                            <input type="checkbox" class="form-check-input" id="privilege{{$privilege['id']}}" name="privilege[]" value="{{$privilege['id']}}">{{$privilege['privilege_name']}}
                                          </label>
                                        </div>
                                        @endforeach
                                    @endif                                                                          
                                    </div>
                                </div>   
                            </div>
                        @endforeach
                    @endif 
                    
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
<script type="text/javascript">

$(document).ready(function(){

    $(document).on("click", ".parentPr", function(event) {   
        var check_status;
        if( $(this).is(':checked') )
            check_status = true;  // checked
        else
            check_status = false;// unchecked

        $(this).parent().next().find("input[type='checkbox']").each(function() {             
            $(this).prop('checked',check_status);            
        });
    });
    
}); 
</script>
@endsection