@extends('layouts.sb_admin')

@section('content')
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Edit Book
  </div>
  <div class="card-body">
    @if ($errors->any())
      <div class="alert alert-danger">
        <ul>
            @foreach ($errors->all() as $error)
              <li>{{ $error }}</li>
            @endforeach
        </ul>
      </div><br />
    @endif
      <form method="post" action="{{ route('privilege_menus.update', $privilege_menu->id) }}">
           
          <div class="form-group">
            @csrf
            @method('PATCH')
            <label>Section Type</label>
            <select class="form-control" name="privilege_menu_category_id">
            @if(!empty($privilege_menu_category_list) )
                @foreach($privilege_menu_category_list as $category_id=> $menu_category)
                  @if( $category_id == $privilege_menu->privilege_menu_category_id )
                    <option value="{{ $category_id }}" selected>{{ $menu_category }}</option>
                  @else 
                    <option value="{{ $category_id }}">{{ $menu_category }}</option>
                  @endif
                @endforeach
            @endif
            </select>
          </div>
          <div class="form-group">                        
              <label for="name">Privilege Name:</label>
              <input type="text" class="form-control" name="privilege_name" value="{{ $privilege_menu->privilege_name }}"/>
          </div> 

          <div class="form-group">
              <label for="name">URI:</label>
              <input type="text" class="form-control" name="uri" value="{{ $privilege_menu->uri }}"/>
          </div> 
          <div class="form-group">
              <label for="name">Methods:</label>
              <input type="text" class="form-control" name="methods" value="{{ $privilege_menu->methods }}"/>
          </div>  
          <div class="form-group">
              <label for="name">Action:</label>
              <input type="text" class="form-control" name="action" value="{{ $privilege_menu->action }}"/>
          </div> 
          <div class="form-group">                        
              <label for="name">Controller:</label>
              <input type="text" class="form-control" name="controller" value="{{ $privilege_menu->controller }}"/>
          </div> 
          <button type="submit" class="btn btn-primary">Update Book</button>
      </form>
  </div>
</div>
@endsection