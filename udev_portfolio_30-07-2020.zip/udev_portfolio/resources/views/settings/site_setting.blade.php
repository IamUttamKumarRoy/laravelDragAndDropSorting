@extends('layouts.sb_admin')
@section('content')

<div class="clearfix"></div>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Setting Option
            </div>
            <div class="panel-body">
                @if ($errors->any())
                <div class="alert alert-danger">
                  <ul>
                      @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                      @endforeach
                  </ul>
                </div><br />
                @endif 
                <form action="{{ route('settings.saveSiteSetting') }}" enctype="multipart/form-data" method="post" >
                    @csrf 
                    
                    {{ show_setting_option($website_settings,$website_setting_values) }}  

                    <button type="submit" class="btn btn-primary">Save </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
@endsection