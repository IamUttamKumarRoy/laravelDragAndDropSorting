<?php $__env->startSection('content'); ?>
            <h1>Showing Book <?php echo e($section_type->book_name); ?></h1>

    <div class="jumbotron text-center">
        <p>
            <strong>Book Title:</strong> <?php echo e($section_type->section_type); ?><br> 
        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>