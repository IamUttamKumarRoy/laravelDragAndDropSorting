<?php $__env->startSection('content'); ?>
<style>
  .uper {
    margin-top: 40px;
  }
</style>
<div class="card uper">
  <div class="card-header">
    Edit Book
  </div>
  <div class="card-body">
    <?php if($errors->any()): ?>
      <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
      </div><br />
    <?php endif; ?>
      <form method="post" action="<?php echo e(route('portfolio_sections.update', $portfolio_section->id)); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <div class="form-group">
                <label>Section Type</label>
                <select class="form-control" name="section_type_id">
                <?php if(!empty($section_type_list) ): ?>
                    <?php $__currentLoopData = $section_type_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section_type_id=> $section_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if( $section_type_id == $portfolio_section->section_type_id ): ?>
                        <option value="<?php echo e($section_type_id); ?>" selected><?php echo e($section_type); ?></option>
                      <?php else: ?> 
                        <option value="<?php echo e($section_type_id); ?>"><?php echo e($section_type); ?></option>
                      <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="section_name">Section Name:</label>
                <input type="text" class="form-control" name="section_name" value="<?php echo e($portfolio_section->section_name); ?>"/>
            </div>
            <div class="form-group">
                <label for="head_title">Head Title:</label>
                <input type="text" class="form-control" name="head_title"  value="<?php echo e($portfolio_section->head_title); ?>"/>
            </div> 
            <div class="form-group">
                <label for="description">Description:</label>
                <textarea class="form-control" name="description"><?php echo e($portfolio_section->description); ?></textarea>
            </div> 
            <button type="submit" class="btn btn-primary">Update</button>
        </form>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>