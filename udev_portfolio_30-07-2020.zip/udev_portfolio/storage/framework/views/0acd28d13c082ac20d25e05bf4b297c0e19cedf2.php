<?php $__env->startSection('content'); ?>
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Privilege Menu Category
            </div>
            <div class="panel-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div><br />
                <?php endif; ?> 
                <form method="post" action="<?php echo e(route('settings.store')); ?>">
                    <div class="form-group">
                        <?php echo csrf_field(); ?>
                        <label for="name">Input Type:</label>
                        <input type="text" class="form-control" name="input_type_id"/>
                    </div> 
                    <div class="form-group">
                        <label for="name">Variable Group:</label>
                        <input type="text" class="form-control" name="variable_group"/>
                    </div> 
                    <div class="form-group">
                        <label for="name">Variable Name:</label>
                        <input type="text" class="form-control" name="variable_name"/>
                    </div>  
                    <div class="form-group">
                        <label for="name">Variable Display Title:</label>
                        <input type="text" class="form-control" name="variable_display_title"/>
                    </div> 
                    <div class="form-group">                        
                        <label for="name">Variable Value:</label>
                        <input type="text" class="form-control" name="variable_value"/>
                    </div> 
                    <div class="form-group">                        
                        <label for="name">Is Singular:</label>
                        <input type="text" class="form-control" name="is_singular"/>
                    </div> 
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>