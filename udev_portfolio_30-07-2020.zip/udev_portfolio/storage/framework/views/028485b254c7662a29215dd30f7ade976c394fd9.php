<?php $__env->startSection('content'); ?>
<br/>
<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading">
              Add Privilege Menu Category
            </div>
            <div class="panel-body">
                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                  <ul>
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </ul>
                </div><br />
                <?php endif; ?>
                <form method="post" action="<?php echo e(route('privilege_menus.store')); ?>">
                    <div class="form-group">
                        <?php echo csrf_field(); ?>
                        <label>Menu Category</label>
                        <select class="form-control" name="privilege_menu_category_id">
                        <?php if(!empty($privilege_menu_category_list) ): ?>
                            <?php $__currentLoopData = $privilege_menu_category_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category_id=> $category_name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($category_id); ?>"><?php echo e($category_name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </select>
                    </div>
                    <div class="form-group">                        
                        <label for="name">Privilege Name:</label>
                        <input type="text" class="form-control" name="privilege_name"/>
                    </div> 

                    <div class="form-group">
                        <label for="name">URI:</label>
                        <input type="text" class="form-control" name="uri"/>
                    </div>
                    <div class="form-group">
                        <label for="name">Route Name:</label>
                        <input type="text" class="form-control" name="route_name"/>
                    </div> 
                    <div class="form-group">
                        <label for="name">Methods:</label>
                        <input type="text" class="form-control" name="methods"/>
                    </div>  
                    <div class="form-group">
                        <label for="name">Action:</label>
                        <input type="text" class="form-control" name="action"/>
                    </div> 
                    <div class="form-group">                        
                        <label for="name">Controller:</label>
                        <input type="text" class="form-control" name="controller"/>
                    </div> 
                    <button type="submit" class="btn btn-primary">Create </button>
                </form>
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.sb_admin', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>