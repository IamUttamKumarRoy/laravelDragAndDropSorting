<?php $__env->startSection('content'); ?>
            <h1>Showing Book <?php echo e($book->book_name); ?></h1>

    <div class="jumbotron text-center">
        <p>
            <strong>Book Title:</strong> <?php echo e($book->book_name); ?><br>
            <strong>Isbn No:</strong> <?php echo e($book->isbn_no); ?>

            <strong>Book Price:</strong> <?php echo e($book->book_price); ?>

        </p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>