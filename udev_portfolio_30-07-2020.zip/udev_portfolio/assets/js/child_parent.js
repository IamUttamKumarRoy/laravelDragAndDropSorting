
$(document).ready(function(){

    $(document).on("click", ".parentPr", function(event) {   
        var check_status;
        if( $(this).is(':checked') )
            check_status = true;  // checked
        else
            check_status = false;// unchecked

        $(this).parent().next().find("input[type='checkbox']").each(function() {             
            $(this).prop('checked',check_status);            
        });
    });
    
}); 